ITOR Author Template
--------------------

The following files are available in itor.zip archive:

itor.cls					- This is the LaTeX2e class file for ITOR template
guide.pdf					- This is PDF of Author Guide for ITOR template
itor-generic-template.pdf	- This is PDF file of sample LaTeX document for ITOR template
itor-generic-template.tex	- This is file of sample LaTeX document for ITOR template
itor.bst					- This is bibliography style file
itor.bib					- This is bibliography database file
fig_1 and fig_2				- Graphic files used in sample EPS format
fig_1 and fig_2				- Graphic files used in sample PDF format

Happy TeXing!!!
Aptara
